# CLI-Control-System
This project is concerned of CLI(Command Line Interface) Control System for a Linux running system. This is made in Python 2.7 on RHEL 7.2

The default username & password is as follows:

username = root (Case-sensitive)

password = redhat (Case-sensitive)

First of all run the login.py file in your computer

Prerequisite for this project to run is Python 2.7 and a Linux System

Never, never and Never try it to run in Windows environment directly. NOT EVEN AT GUN POINT....

Sometimes it gives error in running. If it do so please see what version of python is installed in your system. Python version must be 2.7 because functions of version 2.7 is used


This is open source project and you can change it according to your need.

Please give feedback on metioned email-id: achilleslinux@gmail.com
