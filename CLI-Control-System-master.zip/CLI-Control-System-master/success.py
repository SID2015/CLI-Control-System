#!usr/bin/python

import os
import time
os.system("tput setaf 6")
print("\t\t\tLogin Successfull !!!!.....")
time.sleep(2)
os.system("tput setaf 5")
print("......Now, You'll see Linux related task options......")
time.sleep(5)
print("\t\t\t\t\t\t\t\t\t\t\t\t\n\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\n\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\n\n")		
os.system("python /root/Desktop/RedhatLinux/option.py")
